import Navbar1 from "./navbar1"

const Dashboard=()=>{
    return(
        <div>
            <Navbar1/>
            <h1>Admin Dashboard</h1>
        </div>
    )
}
export default Dashboard
